<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <strong><?php echo e(env('APP_NAME')); ?></strong> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\uploader\resources\views/layouts/footer.blade.php ENDPATH**/ ?>