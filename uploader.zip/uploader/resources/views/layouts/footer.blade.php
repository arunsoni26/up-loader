<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <strong>{{ env('APP_NAME') }}</strong> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
